<?php

    namespace Drupal\event_registration\Plugin\Block;

    use Drupal\Core\Block\BlockBase;

    /**
     * Provides a 'event_registration' block.
     *
     * @Block(
     *   id = "contact_us",
     *   admin_label = @Translation("contact us custom block"),
     *   category = @Translation("Custom contact us example block")
     * )
    */
    class block_example extends BlockBase {

     /**
      * {@inheritdoc}
     */
     public function build() {

       $form = \Drupal::formBuilder()->getForm('Drupal\event_registration\Form\RegistrationForm');

       return $form;
     }
   }