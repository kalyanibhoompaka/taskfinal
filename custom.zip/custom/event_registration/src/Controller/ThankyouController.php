<?php
namespace Drupal\event_registration\Controller;
 
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Database\Database;
 
/**
 * Provides route responses for the Example module.
 */
class ThankyouController extends ControllerBase {
 
  /**
   * Returns a simple page.
   *
   * @return array
   *   A simple renderable array.
   */
  public function successpage() {
  
   
    return [
      '#theme' => 'my_template',
      '#test_var' => $this->t('Successfully submitted form data'),

    ];

  }
 
}