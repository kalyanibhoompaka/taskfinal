<?php
/**
 * @file
 * Contains \Drupal\event_registration\Form\RegistrationForm.
 */
namespace Drupal\event_registration\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;
use Drupal\Core\Database\Connection;
 
class RegistrationForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'event_registration_form';
  }
  
  public function buildForm(array $form, FormStateInterface $form_state) {
    global $user;
    $form['Name'] = array(
      '#type' => 'textfield',
      '#placeholder' => t('Name'),

     
    );
   
    $form['Email'] = array(
      '#type' => 'email',
      '#placeholder' => t('Email'),
    );
   
    $form['SUBJECT'] = array (
      '#type' => 'textfield',
      '#placeholder' => t('SUBJECT'),
    );
    $form['MESSAGE'] = array (
      '#type' => 'textfield',
      '#placeholder' => t('MESSAGE'),
    );

 

   

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
 
      '#value' => $this->t('send'),
      '#button_type' => 'primary',
    );
    $form['#theme'] = 'event_templ';



    return $form;
    
  }
  


  
  

  
  public function submitForm(array &$form, FormStateInterface $form_state) {
    \Drupal::messenger()->addMessage(t("Student Registration Done!! Registered Values are:"));

    $url = Url::fromRoute('event_registration.thankyou');
    $form_state->setRedirectUrl($url);
    
  }


}

