<?php

    namespace Drupal\block_example\Plugin\Block;

    use Drupal\Core\Block\BlockBase;

    /**
     * Provides a 'block_example' block.
     *
     * @Block(
     *   id = "block_example",
     *   admin_label = @Translation("Example block"),
     *   category = @Translation("Custom example block")
     * )
    */
    class block_example extends BlockBase {

     /**
      * {@inheritdoc}
     */
     public function build() {

       $form = \Drupal::formBuilder()->getForm('Drupal\block_example\Form\block_form');

       return $form;
     }
   }