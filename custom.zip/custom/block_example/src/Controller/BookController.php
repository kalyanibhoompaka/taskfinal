<?php
namespace Drupal\block_example\Controller;

class BookController {
    public function Welcome()
    {
        $element = array('#markup' => 'Welcome to Drupal Page',);
        return $element;
    }
}
?>