<?php
/**
 * @file
 * Contains \Drupal\block_example\Form\block_form.
 */
namespace Drupal\block_example\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class block_form extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'blockk_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['employee_mail'] = array(
      '#type' => 'email',
      '#placeholder' => t('Enter Your Email'),
      '#title' => t('NEWSLETTER'),
      '#required' => TRUE,
    );


    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('SUBSCRIBE'),
      '#button_type' => 'primary',
    );
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    \Drupal::messenger()->addMessage(t("Student Registration Done!! Registered Values are:"));
	foreach ($form_state->getValues() as $key => $value) {
	  \Drupal::messenger()->addMessage($key . ': ' . $value);
    }}
}